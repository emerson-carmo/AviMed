import { useEffect, useState } from "react";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Grid,
} from "@mui/material";

import { supabase } from "../services/supabase";
import BarraBotoes from "../components/BarraBotoes";
import TabelaDoencas from "../components/TabelaDoencas";

export default function Doencas() {

  const [lista, setLista] = useState([]);
  const [idSelecionado, setIdSelecionado] = useState(null);

  const [nome, setNome] = useState("");
  const [categoria, setCategoria] = useState("");
  const [sintomas, setSintomas] = useState("");
  const [diagnostico, setDiagnostico] = useState("");
  const [prevencao, setPrevencao] = useState("");
  const [observacoes, setObservacoes] = useState("");

  useEffect(() => {
    carregar();
  }, []);

  async function carregar() {

    const { data, error } = await supabase
      .from("doencas")
      .select("*")
      .order("nome");

    if (error) {
      alert(error.message);
      return;
    }

    setLista(data);

  }

  function limpar() {

    setIdSelecionado(null);

    setNome("");
    setCategoria("");
    setSintomas("");
    setDiagnostico("");
    setPrevencao("");
    setObservacoes("");

  }

  function novo() {
    limpar();
  }

  function editar(item) {

    setIdSelecionado(item.id);

    setNome(item.nome ?? "");
    setCategoria(item.categoria ?? "");
    setSintomas(item.sintomas ?? "");
    setDiagnostico(item.diagnostico ?? "");
    setPrevencao(item.prevencao ?? "");
    setObservacoes(item.observacoes ?? "");

  }

  async function salvar() {

    const registro = {
      nome,
      categoria,
      sintomas,
      diagnostico,
      prevencao,
      observacoes,
    };

    let error;

    if (idSelecionado) {

      ({ error } = await supabase
        .from("doencas")
        .update(registro)
        .eq("id", idSelecionado));

    } else {

      ({ error } = await supabase
        .from("doencas")
        .insert([registro]));

    }

    if (error) {
      alert(error.message);
      return;
    }

    limpar();
    carregar();

  }

  async function excluir() {

    if (!idSelecionado) {
      alert("Selecione um registro.");
      return;
    }

    if (!window.confirm("Deseja excluir esta doença?")) {
      return;
    }

    const { error } = await supabase
      .from("doencas")
      .delete()
      .eq("id", idSelecionado);

    if (error) {
      alert(error.message);
      return;
    }

    limpar();
    carregar();

  }

  return (

    <Box>

      <Typography
        variant="h4"
        align="center"
        mb={3}
      >
        Cadastro de Doenças
      </Typography>

      <Paper sx={{ p: 3 }}>

        <Grid container spacing={2}>

          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              fullWidth
              label="Nome da doença"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              fullWidth
              label="Categoria"
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
            />
          </Grid>

          <Grid size={12}>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Sintomas"
              value={sintomas}
              onChange={(e) => setSintomas(e.target.value)}
            />
          </Grid>

          <Grid size={12}>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Diagnóstico"
              value={diagnostico}
              onChange={(e) => setDiagnostico(e.target.value)}
            />
          </Grid>

          <Grid size={12}>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Prevenção"
              value={prevencao}
              onChange={(e) => setPrevencao(e.target.value)}
            />
          </Grid>

          <Grid size={12}>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Observações"
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
            />
          </Grid>

          <Grid size={12}>

            <BarraBotoes
              onNovo={novo}
              onSalvar={salvar}
              onExcluir={excluir}
              editando={idSelecionado !== null}
            />

          </Grid>

        </Grid>

      </Paper>

      <TabelaDoencas
        dados={lista}
        onSelecionar={editar}
      />

    </Box>

  );

}