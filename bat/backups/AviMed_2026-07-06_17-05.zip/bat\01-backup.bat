@echo off
title Backup AviMed

cd /d "%~dp0.."

echo.
echo ======================================
echo        BACKUP DO AVIMED
echo ======================================
echo.

set DATA=%date:~6,4%-%date:~3,2%-%date:~0,2%
set HORA=%time:~0,2%-%time:~3,2%

if "%HORA:~0,1%"==" " set HORA=0%HORA:~1%

if not exist "bat\backups" mkdir "bat\backups"

set ZIP=AviMed_%DATA%_%HORA%.zip

if exist "%ZIP%" del "%ZIP%"

powershell -NoProfile -Command ^
"Compress-Archive -Path src,public,tools,bat,index.html,package.json,package-lock.json,vite.config.js,README.md,.env,.gitignore,.oxlintrc.json -DestinationPath '%ZIP%' -Force"

move "%ZIP%" "bat\backups\" >nul

echo.
echo ======================================
echo BACKUP CRIADO COM SUCESSO
echo ======================================
echo.

pause